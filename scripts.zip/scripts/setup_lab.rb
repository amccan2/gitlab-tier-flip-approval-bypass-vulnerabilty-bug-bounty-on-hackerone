# GitLab bounty lab seed - run with: gitlab-rails runner /tmp/setup_lab.rb
PASS = 'HuntLab-2026!x'

def ensure_user(username, role_note)
  u = User.find_by(username: username)
  return u if u
  u = Users::CreateService.new(nil, {name: username.capitalize, username: username, email: "#{username}@lab.local", password: PASS, password_confirmation: PASS, skip_confirmation: true, organization_id: Organizations::Organization.default_organization.id}).execute
  u = u.payload if u.respond_to?(:payload)
  raise u.errors.full_messages.inspect if !u.persisted?
  puts "created user #{username}"
  u
end

root = User.find_by(username: 'root')
attacker = ensure_user('attacker', 'Developer')
victim = ensure_user('victim', 'Maintainer')

group = Group.find_by_full_path('acme') || Group.create!(name: 'ACME', path: 'acme', organization: Organizations::Organization.default_organization)

project = Project.find_by_full_path('acme/app')
unless project
  project = Projects::CreateService.new(root, { namespace_id: group.id, name: 'app', path: 'app' }).execute
  raise project.errors.full_messages.inspect unless project.persisted?
end

Members::CreateService.new(root, access_level: 30, user_id: attacker.id, source: project, invite_source: 'lab-seed').execute unless project.member?(attacker)
Members::CreateService.new(root, access_level: 40, user_id: victim.id, source: project, invite_source: 'lab-seed').execute unless project.member?(victim)

# protected branches
[
  { name: 'main', push: [40], merge: [40] },
  { name: 'workloads/*', push: [30], merge: [40] }
].each do |cfg|
  next if project.protected_branches.exists?(name: cfg[:name])
  ProtectedBranches::CreateService.new(container: project, current_user: root, params: {
    name: cfg[:name],
    push_access_levels_attributes: cfg[:push].map { |l| { access_level: l } },
    merge_access_levels_attributes: cfg[:merge].map { |l| { access_level: l } }
  }).execute
end

# protected environment "production": deployable by attacker(user) + Maintainers; 1 approval from Maintainers role rule
# protected environment "staging": deployable by attacker(user); rule 1 = victim user, rule 2 = Maintainers role (candidate B)
[
  {
    name: 'production',
    deploy_access_levels_attributes: [{ user_id: attacker.id }, { access_level: 40 }],
    approval_rules_attributes: [{ access_level: 40, required_approvals: 1 }]
  },
  {
    name: 'staging',
    deploy_access_levels_attributes: [{ user_id: attacker.id }],
    approval_rules_attributes: [{ user_id: victim.id, required_approvals: 1 },
                                { access_level: 40, required_approvals: 1 }]
  }
].each do |cfg|
  next if project.protected_environments.exists?(name: cfg[:name])
  result = ProtectedEnvironments::CreateService.new(container: project, current_user: root, params: cfg).execute
  puts "protected env #{cfg[:name]}: #{result.inspect}"
end

# PATs
[attacker, victim, root].each do |u|
  pat = u.personal_access_tokens.active.where(name: "lab-#{u.username}").last
  unless pat
    pat = PersonalAccessToken.new(user: u, name: "lab-#{u.username}", scopes: [:api, :read_api])
    pat.set_token(SecureRandom.hex(20))
    pat.expires_at = 1.year.from_now
    pat.save!
  end
  puts "PAT #{u.username}: #{pat.token}"
end

puts 'LICENSE: ' + (License.valid? ? 'ACTIVE' : 'NONE - apply trial license!')
puts 'LAB SEEDED OK'
