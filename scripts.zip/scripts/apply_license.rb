result = GitlabSubscriptions::ActivateService.new.execute('hx5C2Ud39ia8zgvMutdnLDea')
puts 'ACTIVATE_RESULT=' + result.inspect
puts 'LICENSE_STATUS=' + (License.current ? License.current.plan.capitalize + ' expires ' + License.current.expires_at.to_s : 'NONE')
