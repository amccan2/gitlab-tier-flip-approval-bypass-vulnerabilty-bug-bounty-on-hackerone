p = Project.find_by_full_path('acme/app')
env = p.environments.find_by(name: 'production') || p.environments.create!(name: 'production')
puts "protected_environments=#{p.licensed_feature_available?(:protected_environments)}"
puts "deployment_approvals=#{p.licensed_feature_available?(:deployment_approvals)}"
puts "env_production_protected=#{env.protected?}"
puts "custom_roles=#{p.licensed_feature_available?(:custom_roles)}"
