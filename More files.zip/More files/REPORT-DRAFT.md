# DRAFT — do not submit until human-verified + screen-recorded

## Title
Broken Access Control: a user with deploy access (but no approval rights) can bypass required
deployment approvals by changing the environment's tier via the API

## Severity suggestion
Let GitLab assign. Similar class (deployment-approval bypass) historically rated Medium–High.
Program bands: Medium $1,000–$2,500.

## Summary
Group-level protected environments protect environments *by tier* (`production`, `staging`, …).
The `PUT /projects/:id/environments/:environment_id` endpoint accepts a `tier` parameter. The
EE policy only prevents `update_environment` when the user is `protected_from?` — i.e. when the
user LACKS deploy access to at least one protecting protected-environment. A user who HAS deploy
access (e.g. a group Developer covered by a `Developers + Maintainers` deploy access level) but is
NOT covered by the approval rule (e.g. approvals require Maintainers) passes `protected_from?`
and can therefore re-tier the environment to `development`, silently detaching the tier-based
protection. Because `Ci::Build#playable?` (EE) re-evaluates `waiting_for_deployment_approval?`
against the now-unprotected environment, an approval-blocked deployment becomes immediately
playable and runs with zero approvals.

The approval requirement exists exactly to constrain users who may deploy; this lets any such
user bypass it, defeating segregation of duties on protected tiers.

## Affected
- GitLab EE (Premium+), tested on 19.5.1 self-managed with an active Ultimate trial license
- Both group-level (tier-scoped) protection; same re-tiering logic affects project-scoped envs
  whose name-based protection would also be re-evaluated after rename-adjacent updates where
  permitted

## Steps (full log + JSON in poc-evidence/, script: poc_tier_flip_approval_bypass.sh)
1. As admin: protect group tier `production` — deploy access level: `Developers + Maintainers (30)`;
   approval rule: `Maintainers (40)` requiring 1 approval.
2. As attacker (Developer role in group + project, covered by deploy access level, NOT an approver):
   create environment `website` with tier `production` and a manual deploy job
   (`environment: name: website, deployment_tier: production`) on branch `workloads/poc`.
3. Deployment for `website` is created `blocked` (awaiting Maintainer approval).
   CONTROL: `POST /jobs/:id/play` → **403 Forbidden** (gate correctly enforced).
4. ATTACK: `PUT /projects/:id/environments/:id?tier=development` → **200 OK**.
   No approval was cast; the attacker's deploy access makes `protected_from?` false, so the
   update policy permits the change — including the attribute the protection keys on.
5. `POST /jobs/:id/play` → **200 OK**; job runs; deployment reaches **success** with zero
   approvals (deployment_approvals table empty for this deployment).

## Root cause
- `ee/app/policies/ee/environment_policy.rb`: `prevent :update_environment` only under
  `protected_environment` = `@subject.protected_from?(user)`.
- `app/models/ee/environment.rb#protected_from?`: true only when the user lacks deploy access to
  SOME protecting PE; deploy-accessible users are treated as fully trusted for ALL environment
  mutations, including `tier`.
- `app/services/environments/update_service.rb`: `tier` is in `ALLOWED_ATTRIBUTES`.
- `ee/app/models/ee/ci/build.rb`: `playable? = super && !waiting_for_deployment_approval?`, and
  `waiting_for_approval?`/`pending_approval_count` re-derive from `environment.protected?`, which
  is now false.

## Suggested fix
Exclude `tier` (and any attribute that protection matching keys on) from user-updatable
attributes for environments matched by a protected environment, or gate the update on the user
holding `admin_protected_environments` when the environment is matched by ANY protected
environment (regardless of the requester's deploy access).

## Prior-art / duplicates checked
- gitlab-org/gitlab#628468 — CI-config `deployment_tier` change evading group-tier deploy access
  (open). This report is a DIFFERENT vector: the environment-update API, exercised by an
  authorized deployer, defeating APPROVALS (not just deploy access), with no code/CI change.
- Tracker search (tier/protected/approval): only feature requests; no known duplicate.
- Known fixed CVEs in this area: CVE-2023-4700, CVE-2026-86340/86341, CVE-2026-1752 — unrelated.
- HackerOne hacktivity: no disclosed report for tier-based protection detachment.

## AI disclosure (mandatory)
This research was AI-assisted (Claude Code, terminal agent). Every request/response above was
executed and verified by me on my own self-managed instance; the control run and the impact
state (deployment success with zero approvals) were confirmed manually and on screen recording.

## Evidence checklist before submitting
- [ ] Human re-runs poc_tier_flip_approval_bypass.sh locally, confirms each step
- [ ] Screen recording: control 403 → tier flip 200 → play 200 → deployment success
- [ ] `GET /api/v4/version` output (19.5.1-ee) captured
- [ ] License state (Ultimate trial active) captured
- [ ] gitlab:check healthy output
