# frozen_string_literal: true

class GroupMemberPolicy < BasePolicy
  include MemberPolicyHelpers

  delegate :group

  with_scope :subject
  condition(:last_owner) { @subject.last_owner_of_the_group? }
  condition(:project_bot) { @subject.user&.project_bot? && @subject.group.member?(@subject.user) }

  desc "Membership is users' own"
  with_score 0
  condition(:target_is_self) { record_belongs_to_self? }

  desc "Membership is users' own access request"
  with_score 0
  condition(:access_request_of_self) { record_is_access_request_of_self? }

  rule { anonymous }.policy do
    prevent :update_group_member
    prevent :destroy_group_member
  end

  rule { last_owner }.policy do
    prevent :update_group_member
    prevent :destroy_group_member
  end

  # Not gated on admin_group_member, which read-only (archived or pending deletion) groups
  # prevent: they block adding members, but removing them must keep working.
  condition(:can_remove_group_members) do
    can?(:destroy_group_member, @subject.group)
  end

  rule { project_bot & can_remove_group_members }.enable :destroy_project_bot_member

  # Project bot members must be managed via :destroy_project_bot_member and
  # the access-token revoke flow, not via the regular member update/destroy
  # abilities, since their role is bound to the access-token scope.
  rule { project_bot }.policy do
    prevent :update_group_member
    prevent :destroy_group_member
  end

  rule { target_is_self }.policy do
    enable :destroy_group_member
  end

  rule { access_request_of_self }.policy do
    enable :withdraw_member_access_request
  end
end

GroupMemberPolicy.prepend_mod_with('GroupMemberPolicy')
