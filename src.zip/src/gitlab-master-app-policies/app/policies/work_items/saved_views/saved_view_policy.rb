# frozen_string_literal: true

module WorkItems
  module SavedViews
    class SavedViewPolicy < BasePolicy
      delegate { @subject.resource_parent }

      # Require users be logged in before they can create, read, update or delete saved views
      rule { anonymous }.prevent_all

      # Require users to be able to read the namespace before they can interact with saved views
      rule { ~can_read_namespace }.prevent_all

      # Only authors are granted access to shared views that are private
      rule { is_private & ~is_author }.prevent_all

      # Only the author can change a shared saved view's visibility
      rule { ~is_author }.prevent :update_saved_view_visibility

      condition(:can_read_namespace) do
        can?(:read_namespace, @subject.namespace)
      end

      condition(:is_author) do
        @user && @subject.created_by_id == @user.id
      end

      condition(:is_private) do
        @subject.private?
      end

      rule { ~can?(:_update_shared_saved_view) }.policy do
        prevent :update_saved_view
        prevent :update_saved_view_visibility
      end

      # Authors below Planner keep delete on their private views, since no one else can see or delete them.
      rule { ~can?(:_delete_shared_saved_view) & ~is_private }.prevent :delete_saved_view

      rule { can?(:update_saved_view) }.enable :update_work_item_saved_view
      rule { can?(:delete_saved_view) }.enable :delete_work_item_saved_view

      rule { ~is_private }.policy do
        enable :read_saved_view
      end

      # Subscribe, unsubscribe and reorder act only on the current user's own subscription, not on the saved view
      # itself, so they require nothing more than the ability to read the view.
      rule { can?(:read_saved_view) }.policy do
        enable :subscribe_saved_view
        enable :unsubscribe_saved_view
        enable :reorder_saved_view
      end

      rule { can?(:subscribe_saved_view) }.enable :subscribe_work_item_saved_view
      rule { can?(:unsubscribe_saved_view) }.enable :unsubscribe_work_item_saved_view
      rule { can?(:reorder_saved_view) }.enable :reorder_work_item_saved_view
    end
  end
end
