# frozen_string_literal: true

module Ai
  module Catalog
    module GoalTemplates
      class Developer
        class RequestedChanges
          # The reviewer's name is never an @-mention: a mention of GitLab Duo starts a Duo Code Review chat.
          TEMPLATE = <<~GOAL.strip
            The reviewer %{reviewer_username} requested changes on the merge request %{resource_url}.
            Fix the merge request so that it addresses the review.

            - Work only on this merge request. Push to its source branch.
            - Read each unresolved thread that %{reviewer_username} started on this merge request. For each thread, change the code, or decide that no change is necessary.
            - Push all fixes in one push. Each push starts a new review.
            - Reply in each of these threads with the fix, or with the reason for no change.
            - Do not resolve the threads.
            - Do not change the title or the draft state of the merge request.
            - Do not mention %{reviewer_username} with `@`.
          GOAL

          def self.template
            TEMPLATE
          end

          def self.vars(resource:, params:, **_)
            {
              resource_url: Gitlab::UrlBuilder.build(resource),
              reviewer_username: params[:reviewer_username].to_s
            }
          end
        end
      end
    end
  end
end
