# frozen_string_literal: true

module Ai
  module DuoWorkflows
    class SessionFile < ::ApplicationRecord
      self.table_name = :duo_workflows_session_files

      belongs_to :workflow, class_name: 'Ai::DuoWorkflows::Workflow', optional: true
      belongs_to :project, optional: true
      belongs_to :namespace, optional: true

      populate_sharding_key :project_id, source: :workflow
      populate_sharding_key :namespace_id, source: :workflow

      validates :size, presence: true, numericality: { greater_than_or_equal_to: 0 }
      validates :file, presence: true, length: { maximum: 255 }
      validates :content_type, presence: true, length: { maximum: 255 }
    end
  end
end
